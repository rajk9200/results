﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","zh-cn",{title:"元素信息",dialogName:"对话框窗口名称",tabName:"选项卡名称",elementId:"元素 ID",elementType:"元素类型"});